﻿#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <climits>
#ifdef _WIN32
#include <windows.h>
#endif

using namespace std;

using Exponents = array<int, 26>;
using Polynomial = map<Exponents, long long>;

static long long checkedAdd(long long left, long long right) {
	if ((right > 0 && left > LLONG_MAX - right) ||
		(right < 0 && left < LLONG_MIN - right)) {
		throw overflow_error("系数运算超出 long long 范围");
	}
	return left + right;
}

static bool checkedMultiply(long long left, long long right, long long& result) {
	if (left == 0 || right == 0) {
		result = 0;
		return true;
	}
	if ((left == -1 && right == LLONG_MIN) || (right == -1 && left == LLONG_MIN)) return false;
	if (left > 0) {
		if ((right > 0 && left > LLONG_MAX / right) ||
			(right < 0 && right < LLONG_MIN / left)) return false;
	} else {
		if ((right > 0 && left < LLONG_MIN / right) ||
			(right < 0 && left < LLONG_MAX / right)) return false;
	}
	result = left * right;
	return true;
}

static void addTerm(Polynomial& polynomial, const Exponents& exponents, long long coefficient) {
	if (coefficient == 0) return;
	auto found = polynomial.find(exponents);
	if (found == polynomial.end()) {
		polynomial[exponents] = coefficient;
	} else {
		found->second = checkedAdd(found->second, coefficient);
		if (found->second == 0) polynomial.erase(found);
	}
}

static Polynomial constantPolynomial(long long value) {
	Polynomial result;
	Exponents exponents{};
	addTerm(result, exponents, value);
	return result;
}

static Polynomial multiply(const Polynomial& left, const Polynomial& right) {
	Polynomial result;
	for (const auto& a : left) {
		for (const auto& b : right) {
			Exponents exponents{};
			for (int i = 0; i < 26; ++i) exponents[i] = a.first[i] + b.first[i];
			long long coefficient;
			if (!checkedMultiply(a.second, b.second, coefficient)) {
				throw overflow_error("系数运算超出 long long 范围");
			}
			addTerm(result, exponents, coefficient);
		}
	}
	return result;
}

static long long gcdValue(long long a, long long b) {
	a = llabs(a);
	b = llabs(b);
	while (b != 0) {
		long long remainder = a % b;
		a = b;
		b = remainder;
	}
	return a;
}

static bool squareRoot(long long value, long long& root) {
	if (value < 0) return false;
	root = static_cast<long long>(sqrt(static_cast<long double>(value)));
	while (root > 0 && root > value / root) --root;
	while (root < 3037000499LL && (root + 1) <= value / (root + 1)) ++root;
	return root * root == value;
}

static string polynomialToString(const Polynomial& polynomial) {
	if (polynomial.empty()) return "0";
	ostringstream output;
	bool first = true;
	for (auto it = polynomial.rbegin(); it != polynomial.rend(); ++it) {
		long long coefficient = it->second;
		if (!first) output << (coefficient < 0 ? " - " : " + ");
		else if (coefficient < 0) output << '-';

		long long absoluteCoefficient = llabs(coefficient);
		bool hasVariable = false;
		for (int exponent : it->first) hasVariable = hasVariable || exponent != 0;
		if (absoluteCoefficient != 1 || !hasVariable) output << absoluteCoefficient;

		for (int i = 0; i < 26; ++i) {
			if (it->first[i] == 0) continue;
			output << static_cast<char>('a' + i);
			if (it->first[i] != 1) output << '^' << it->first[i];
		}
		first = false;
	}
	return output.str();
}

static string productToString(const vector<Polynomial>& factors) {
	if (factors.empty()) return "1";
	ostringstream output;
	for (size_t i = 0; i < factors.size(); ++i) {
		if (i != 0) output << " * ";
		const Polynomial& factor = factors[i];
		string text = polynomialToString(factor);
		if (factor.size() > 1) output << '(' << text << ')';
		else output << text;
	}
	return output.str();
}

class Parser {
public:
	explicit Parser(const string& text) : text_(text), position_(0) {}

	Polynomial parse() {
		Polynomial result = parseExpression();
		skipSpaces();
		if (position_ != text_.size()) fail("存在无法识别的字符");
		return result;
	}

private:
	const string& text_;
	size_t position_;

	void skipSpaces() {
		while (position_ < text_.size() && isspace(static_cast<unsigned char>(text_[position_]))) ++position_;
	}

	bool startsAtom() {
		skipSpaces();
		if (position_ >= text_.size()) return false;
		unsigned char ch = static_cast<unsigned char>(text_[position_]);
		return isalpha(ch) || isdigit(ch) || text_[position_] == '(';
	}

	[[noreturn]] void fail(const string& message) const {
		throw runtime_error(message + "，位置 " + to_string(position_ + 1));
	}

	Polynomial parseExpression() {
		Polynomial result = parseProduct();
		while (true) {
			skipSpaces();
			if (position_ >= text_.size() || (text_[position_] != '+' && text_[position_] != '-')) break;
			char operation = text_[position_++];
			Polynomial next = parseProduct();
			for (const auto& term : next) {
				addTerm(result, term.first, operation == '+' ? term.second : -term.second);
			}
		}
		return result;
	}

	Polynomial parseProduct() {
		Polynomial result = parseUnary();
		while (true) {
			skipSpaces();
			if (position_ < text_.size() && text_[position_] == '*') {
				++position_;
				result = multiply(result, parseUnary());
			} else if (startsAtom()) {
				result = multiply(result, parseUnary());
			} else {
				break;
			}
		}
		return result;
	}

	Polynomial parseUnary() {
		skipSpaces();
		if (position_ < text_.size() && (text_[position_] == '+' || text_[position_] == '-')) {
			char sign = text_[position_++];
			Polynomial result = parseUnary();
			if (sign == '-') {
				for (auto& term : result) term.second = -term.second;
			}
			return result;
		}
		return parsePower();
	}

	Polynomial parsePower() {
		Polynomial base = parsePrimary();
		skipSpaces();
		if (position_ >= text_.size() || text_[position_] != '^') return base;
		++position_;
		skipSpaces();
		if (position_ >= text_.size() || !isdigit(static_cast<unsigned char>(text_[position_]))) {
			fail("指数必须是非负整数");
		}
		unsigned long long exponent = 0;
		while (position_ < text_.size() && isdigit(static_cast<unsigned char>(text_[position_]))) {
			exponent = exponent * 10 + static_cast<unsigned>(text_[position_++] - '0');
			if (exponent > 1000) fail("指数过大");
		}
		Polynomial result = constantPolynomial(1);
		for (unsigned long long i = 0; i < exponent; ++i) result = multiply(result, base);
		return result;
	}

	Polynomial parsePrimary() {
		skipSpaces();
		if (position_ >= text_.size()) fail("缺少因子");
		char ch = text_[position_];
		if (ch == '(') {
			++position_;
			Polynomial result = parseExpression();
			skipSpaces();
			if (position_ >= text_.size() || text_[position_] != ')') fail("缺少右括号");
			++position_;
			return result;
		}
		if (isdigit(static_cast<unsigned char>(ch))) {
			size_t start = position_;
			while (position_ < text_.size() && isdigit(static_cast<unsigned char>(text_[position_]))) ++position_;
			long long value;
			try {
				value = stoll(text_.substr(start, position_ - start));
			} catch (const exception&) {
				fail("整数超出 long long 范围");
			}
			return constantPolynomial(value);
		}
		if (isalpha(static_cast<unsigned char>(ch))) {
			++position_;
			char lower = static_cast<char>(tolower(static_cast<unsigned char>(ch)));
			Exponents exponents{};
			exponents[lower - 'a'] = 1;
			Polynomial result;
			addTerm(result, exponents, 1);
			return result;
		}
		fail("缺少有效因子");
	}
};

struct Split {
	string rule;
	vector<Polynomial> factors;
};

static Polynomial monomial(long long coefficient, const Exponents& exponents) {
	Polynomial result;
	addTerm(result, exponents, coefficient);
	return result;
}

static bool tryCommonFactor(const Polynomial& polynomial, Split& split) {
	if (polynomial.size() < 2) return false;
	long long coefficientGcd = 0;
	Exponents common = polynomial.begin()->first;
	for (const auto& term : polynomial) {
		coefficientGcd = gcdValue(coefficientGcd, term.second);
		for (int i = 0; i < 26; ++i) common[i] = min(common[i], term.first[i]);
	}
	bool hasVariable = false;
	for (int exponent : common) hasVariable = hasVariable || exponent > 0;
	if (coefficientGcd <= 1 && !hasVariable) return false;

	long long commonCoefficient = polynomial.rbegin()->second < 0 ? -coefficientGcd : coefficientGcd;
	Polynomial factor = monomial(commonCoefficient, common);
	Polynomial remainder;
	for (const auto& term : polynomial) {
		Exponents exponents{};
		for (int i = 0; i < 26; ++i) exponents[i] = term.first[i] - common[i];
		addTerm(remainder, exponents, term.second / commonCoefficient);
	}
	if (multiply(factor, remainder) != polynomial) return false;
	split = {"提取公因式", {factor, remainder}};
	return true;
}

static bool tryPerfectSquare(const Polynomial& polynomial, Split& split);

static bool tryDifferenceOfSquares(const Polynomial& polynomial, Split& split) {
	if (polynomial.size() == 4) {
		vector<pair<Exponents, long long>> terms(polynomial.begin(), polynomial.end());
		for (int excluded = 0; excluded < 4; ++excluded) {
			long long root;
			if (terms[excluded].second >= 0 || !squareRoot(-terms[excluded].second, root)) continue;
			Exponents rootExponents{};
			bool evenPowers = true;
			for (int i = 0; i < 26; ++i) {
				if (terms[excluded].first[i] % 2 != 0) evenPowers = false;
				rootExponents[i] = terms[excluded].first[i] / 2;
			}
			if (!evenPowers) continue;

			Polynomial squarePart = polynomial;
			squarePart.erase(terms[excluded].first);
			Split squareSplit;
			if (!tryPerfectSquare(squarePart, squareSplit)) continue;
			Polynomial base = squareSplit.factors.front();
			Polynomial squareRootTerm = monomial(root, rootExponents);
			Polynomial sum = base;
			for (const auto& term : squareRootTerm) addTerm(sum, term.first, term.second);
			Polynomial difference = base;
			for (const auto& term : squareRootTerm) addTerm(difference, term.first, -term.second);
			if (multiply(sum, difference) != polynomial) continue;
			split = {"平方差公式", {sum, difference}};
			return true;
		}
		return false;
	}
	if (polynomial.size() != 2) return false;
	const auto& first = *polynomial.begin();
	const auto& second = *next(polynomial.begin());
	const pair<const Exponents, long long>* positive = &first;
	const pair<const Exponents, long long>* negative = &second;
	if (positive->second < 0) swap(positive, negative);
	if (positive->second <= 0 || negative->second >= 0) return false;

	long long positiveRoot, negativeRoot;
	if (!squareRoot(positive->second, positiveRoot) || !squareRoot(-negative->second, negativeRoot)) return false;
	Exponents leftExponents{}, rightExponents{};
	for (int i = 0; i < 26; ++i) {
		if (positive->first[i] % 2 != 0 || negative->first[i] % 2 != 0) return false;
		leftExponents[i] = positive->first[i] / 2;
		rightExponents[i] = negative->first[i] / 2;
	}
	Polynomial left = monomial(positiveRoot, leftExponents);
	Polynomial right = monomial(negativeRoot, rightExponents);
	Polynomial sum = left;
	for (const auto& term : right) addTerm(sum, term.first, term.second);
	Polynomial difference = left;
	for (const auto& term : right) addTerm(difference, term.first, -term.second);
	if (multiply(sum, difference) != polynomial) return false;
	split = {"平方差公式", {sum, difference}};
	return true;
}

static bool tryPerfectSquare(const Polynomial& polynomial, Split& split) {
	if (polynomial.size() != 3) return false;
	vector<pair<Exponents, long long>> terms(polynomial.begin(), polynomial.end());
	for (int i = 0; i < 3; ++i) {
		for (int j = i + 1; j < 3; ++j) {
			int k = 3 - i - j;
			if (k < 0 || k > 2) continue;
			long long rootI, rootJ;
			if (terms[i].second <= 0 || terms[j].second <= 0 ||
				!squareRoot(terms[i].second, rootI) || !squareRoot(terms[j].second, rootJ)) continue;
			Exponents exponentsI{}, exponentsJ{};
			bool evenPowers = true;
			for (int v = 0; v < 26; ++v) {
				if (terms[i].first[v] % 2 != 0 || terms[j].first[v] % 2 != 0) evenPowers = false;
				exponentsI[v] = terms[i].first[v] / 2;
				exponentsJ[v] = terms[j].first[v] / 2;
			}
			if (!evenPowers) continue;

			Polynomial left = monomial(rootI, exponentsI);
			Polynomial right = monomial(rootJ, exponentsJ);
			Polynomial cross = multiply(left, right);
			for (auto& term : cross) {
				if (!checkedMultiply(term.second, 2, term.second)) {
					throw overflow_error("系数运算超出 long long 范围");
				}
			}
			if (cross.size() != 1 || cross.begin()->first != terms[k].first) continue;

			Polynomial base = left;
			bool plus = terms[k].second == cross.begin()->second;
			bool minus = terms[k].second == -cross.begin()->second;
			if (!plus && !minus) continue;
			for (const auto& term : right) addTerm(base, term.first, plus ? term.second : -term.second);
			if (multiply(base, base) != polynomial) continue;
			split = {"完全平方公式", {base, base}};
			return true;
		}
	}
	return false;
}

static bool tryCrossMultiplication(const Polynomial& polynomial, Split& split) {
	if (polynomial.size() != 3) return false;
	const Exponents zero{};
	const pair<const Exponents, long long>* constant = nullptr;
	vector<const pair<const Exponents, long long>*> nonconstant;
	for (const auto& term : polynomial) {
		if (term.first == zero) constant = &term;
		else nonconstant.push_back(&term);
	}
	if (constant == nullptr || nonconstant.size() != 2) return false;

	const pair<const Exponents, long long>* leading = nullptr;
	const pair<const Exponents, long long>* middle = nullptr;
	for (int i = 0; i < 2; ++i) {
		for (int j = 0; j < 2; ++j) {
			if (i == j) continue;
			bool isSquare = true;
			for (int variable = 0; variable < 26; ++variable) {
				if (nonconstant[i]->first[variable] != 2 * nonconstant[j]->first[variable]) {
					isSquare = false;
					break;
				}
			}
			if (isSquare) {
				leading = nonconstant[i];
				middle = nonconstant[j];
				break;
			}
		}
		if (leading != nullptr) break;
	}
	if (leading == nullptr) return false;

	long long a = leading->second;
	long long b = middle->second;
	long long c = constant->second;
	if (a == 0 || b == 0 || c == 0) return false;
	long long ac;
	if (!checkedMultiply(a, c, ac)) return false;
	if (ac == 0 || ac == LLONG_MIN) return false;
	long long magnitude = llabs(ac);

	for (long long divisor = 1; divisor <= magnitude / divisor; ++divisor) {
		if (magnitude % divisor != 0) continue;
		long long quotient = magnitude / divisor;
		vector<pair<long long, long long>> candidates;
		if (ac > 0) {
			candidates.push_back({divisor, quotient});
			candidates.push_back({-divisor, -quotient});
		} else {
			candidates.push_back({divisor, -quotient});
			candidates.push_back({-divisor, quotient});
		}
		for (const auto& candidate : candidates) {
			long long p = candidate.first;
			long long q = candidate.second;
			if ((q > 0 && p > LLONG_MAX - q) || (q < 0 && p < LLONG_MIN - q) || p + q != b) continue;

			long long g = gcdValue(a, p);
			if (g == 0) continue;
			long long firstCoefficient = a / g;
			if (firstCoefficient == 0 || q % firstCoefficient != 0) continue;
			long long h = q / firstCoefficient;
			long long constantProduct;
			if (!checkedMultiply(h, p / g, constantProduct) || constantProduct != c) continue;

			Polynomial first = monomial(g, middle->first);
			addTerm(first, Exponents{}, h);
			Polynomial second = monomial(a / g, middle->first);
			addTerm(second, Exponents{}, p / g);
			if (multiply(first, second) != polynomial) continue;
			split = {"十字相乘法", {first, second}};
			return true;
		}
	}
	return false;
}

static vector<Polynomial> factorRecursively(const Polynomial& polynomial, vector<string>& steps, int depth = 0) {
	if (depth >= 100 || polynomial.size() < 2) return {polynomial};

	Split split;
	bool found = tryCommonFactor(polynomial, split) ||
				 tryDifferenceOfSquares(polynomial, split) ||
				 tryPerfectSquare(polynomial, split) ||
				 tryCrossMultiplication(polynomial, split);
	if (!found) return {polynomial};

	ostringstream step;
	step << string(static_cast<size_t>(depth) * 2, ' ')
		 << '[' << split.rule << "] " << polynomialToString(polynomial)
		 << " = " << productToString(split.factors);
	steps.push_back(step.str());

	vector<Polynomial> result;
	for (const Polynomial& factor : split.factors) {
		vector<Polynomial> subFactors = factorRecursively(factor, steps, depth + 1);
		result.insert(result.end(), subFactors.begin(), subFactors.end());
	}
	return result;
}

int main() {
#ifdef _WIN32
	SetConsoleOutputCP(CP_UTF8);
	SetConsoleCP(CP_UTF8);
#endif
	cout << "请输入多项式（例如 x^2+2xy+y^2）：\n";
	string input;
	if (!getline(cin, input)) return 0;

	try {
		Parser parser(input);
		Polynomial polynomial = parser.parse();
		vector<string> steps;
		vector<Polynomial> factors = factorRecursively(polynomial, steps);

		cout << "\n分解过程：\n";
		if (steps.empty()) cout << "未找到适用的分解形式。\n";
		else for (const string& step : steps) cout << step << '\n';
		cout << "\n最终结果：\n" << polynomialToString(polynomial)
			 << " = " << productToString(factors) << '\n';
	} catch (const exception& error) {
		cerr << "输入错误：" << error.what() << '\n';
		return 1;
	}
	std::system("pause");
	return 0;
}
